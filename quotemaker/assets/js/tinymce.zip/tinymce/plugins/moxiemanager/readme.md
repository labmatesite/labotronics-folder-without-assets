MoxieManager-PHP
==================

...

Installation
==================
npm install -g jake
npm install less amdlc jshint node-native-zip glob
pear install PHP_CodeSniffer

